package com.myssm.ioc;

public interface BeanFactory {
    Object getBean(String id);
}
