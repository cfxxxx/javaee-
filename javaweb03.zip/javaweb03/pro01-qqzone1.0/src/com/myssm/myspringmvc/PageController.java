package com.myssm.myspringmvc;

public class PageController {
    public String page(String page){
        return page ;       // frames/left
    }
}
