package com.qqzone.service.impl;

import com.qqzone.dao.UserBasicDAO;
import com.qqzone.dao.impl.UserBasicDAOImpl;
import com.qqzone.pojo.UserBasic;
import com.qqzone.service.UserBasicService;

import java.util.List;

public class UserBasicServiceImpl implements UserBasicService {
    private UserBasicDAO userBasicDAO = null;

    @Override
    public UserBasic login(String loginId, String pwd) {
        return userBasicDAO.getUserBasic(loginId, pwd);
    }

    @Override
    public List<UserBasic> getFriendList(UserBasic userBasic) {
        return userBasicDAO.getUsersBasicList(userBasic);
    }
}
