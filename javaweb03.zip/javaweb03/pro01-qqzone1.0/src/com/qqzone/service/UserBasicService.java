package com.qqzone.service;

import com.qqzone.pojo.UserBasic;

import java.util.List;

public interface UserBasicService {
    //实现登录功能
    public UserBasic login(String loginId, String pwd);
    //获取好友列表
    public List<UserBasic> getFriendList(UserBasic userBasic);
}
