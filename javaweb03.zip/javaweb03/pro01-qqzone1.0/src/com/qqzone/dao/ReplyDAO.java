package com.qqzone.dao;

import com.qqzone.pojo.Reply;
import com.qqzone.pojo.Topic;

import java.util.List;

public interface ReplyDAO {
    //获取指定日志的回复列表
    public List<Reply> getReplyList(Topic topic);
    //添加回复
    public void addReply(Reply reply);
    //删除回复
    public void delReply(Integer id);
}
