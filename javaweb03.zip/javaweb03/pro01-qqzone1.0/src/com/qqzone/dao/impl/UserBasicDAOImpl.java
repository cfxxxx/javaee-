package com.qqzone.dao.impl;

import com.myssm.basedao.BaseDAO;
import com.qqzone.dao.UserBasicDAO;
import com.qqzone.pojo.UserBasic;

import java.util.List;

public class UserBasicDAOImpl extends BaseDAO<UserBasic> implements UserBasicDAO{

    @Override
    public UserBasic getUserBasic(String loginId, String pwd) {
        return load("select * from t_user_basic where loginId=? and pwd=?", loginId, pwd);
    }

    @Override
    public List<UserBasic> getUsersBasicList(UserBasic userBasic) {
        return executeQuery("select t3.* from t_user_basic t1 left join t_friend t2 on t1.id = t2.uid inner join t_user_basic t3 on t2.fid=t3.id and t1.id=?", userBasic.getId());
    }
}
