package com.qqzone.dao;

public interface HostReplyDAO {
}
