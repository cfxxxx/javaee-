# Thymeleaf - 视图模板技术

1. 添加thymeleaf的jar包
2. 新建一个Servlet类ViewBaseServlet
3. 在web.xml文件中添加配置

   -- 配置前缀 prefix

   -- 配置后缀 suffix
4. 使得我们的Servlet继承ViewBaseServlet
5. 根据逻辑视图名称得到物理视图名称

   super.processTemplate("index", request, response);
6. 使用thymeleaf的标签

   th:if        th:unless        th:each        th:text

# 保存作用域

原始情况下，保存作用域我们可以认为有四个：page（页面级别，现在几乎不用），request（一次请求响应范围），session（一次会话范围），application（整个应用程序范围）

1. request：一次请求响应范围
2. session：一次会话范围有效（不同的客户端是不同的会话）
3. application：一次应用程序范围有效（整个服务器范围内有效）

# 路径问题

- 相对路径：../返回上一级
- 绝对路径：http://localhost:8080/根目录

  \<base href="http://localhost:8080/pro/" />的作用是：当前页面上的所有路径都以这个路径为基础

  在thymeleaf中，th:href="@{路径}" 表示大括号里的路径都以base href为基础

# Servlet的初始化方法

1. Servlet的生命周期：实例化，初始化，服务，销毁
2. Servlet中的初始化方法有两个：init(),    init(config)

   其中带参数的方法如下：
   ```java
   public void init(ServletConfig config) throws ServletException {
       this.config = config;
       this.init();
   }
   ```

   另一个无参的方法如下：
   ```java
   public void init() throws ServletException {
   }
   ```

   如果我们想要在Servlet初始化时做一些准备工作，那么我们可以重写init方法

   我们可以通过如下步骤去获取初始化设置的数据

   -- 获取config对象： ServletConfig servletConfig = getServletConfig();

   -- 获取初始化参数值：servletConfig.getInitParameter("key");
3. 在web.xml文件中配置Servlet
   ```xml
   <servlet>
       <servlet-name>Demo01</servlet-name>
       <servlet-class>com.servlets.Demo01Servlet</servlet-class>
       <init-param>
           <param-name>hello</param-name>
           <param-value>world</param-value>
       </init-param>
       <init-param>
           <param-name>uname</param-name>
           <param-value>jim</param-value>
       </init-param>
   </servlet>
   <servlet-mapping>
       <servlet-name>Demo01</servlet-name>
       <url-pattern>/Demo01</url-pattern>
   </servlet-mapping>
   ```
4. 也可以通过注解的方式进行配置
   ```java
   @WebServlet(urlPatterns = {"/Demo01"}, initParams = {
           @WebInitParam(name = "hello", value = "world"),
           @WebInitParam(name = "uname", value = "jim")
   })
   ```

# Servlet中的ServletContext

1. 获取ServletContext，有很多方法

   在初始化方法中：ServletContext servletContext = getServletContext();

   在服务方法中也可以通过request对象获取，也可以通过session获取：

   req.getServletContext();

   session.getServletContext();
2. 获取初始化值：

   servletContext.getInitParameter("key");

# 业务层

1. MVC：Model（模型），View（视图），Controller（控制器）

   视图层：用于做数据展示以及和用户交互的一个界面

   控制层：能够接受客户端的请求，具体的业务功能还是要借助于模型组件来完成

   模型层：模型分为很多种：由比较简单的bean/pojo，有业务模型组件，由数据访问层组件
   1. pojo/bean/vo：值对象
   2. DAO：数据访问对象
   3. BO/Service：业务对象
   4. DTO：数据传输对象

   区分业务对象和数据访问对象：
   1. DAO中的方法都是单精度方法（细粒度方法）。一个方法只考虑一个操作
   2. BO中的方法数据业务方法，实际的业务是比较复杂的，因此也业务方法的粒度是比较粗的

# IOC

1. 耦合/依赖

   在软件系统中，层与层之间是存在依赖的。我们也称之为耦合

   我们的系统架构的原则是：高内聚，低耦合

   层内部的组成应该是高度聚合的，而层与层之间的关系应该是低耦合的，最理想的情况是0耦合（就是没有耦合）
2. IOC    -    控制反转    /    DI    -    依赖注入

   控制反转：
   1. 之前在Servlet中，我们创建service对象，FruitService fruitService = new FruitService()

      这句话如果出现在servlet中的某个方法内部，那么这个fruitService的作用域（生命周期）就是这个方法级别

      如果这句话出现在servlet的类中，也就是说fruitService是一个成员变量，那么这个fruitService的作用域（生命周期）就是这个servlet实例级别
   2. 之后在applicationContext.xml中定义了这个fruitService，然后通过解析XML文件，产生fruitService实例，存放在beanMap中，这个beanMap存放在beanFactory中

      因此，我们转移（改变）了之前的service实例，dao实例等等他们的生命周期，控制权从程序员转移到BeanFactory，这个现象称之为控制反转

   依赖注入：
   1. 之前我们在控制层出现代码：FruitService fruitService = new FruitService()

      那么，控制层和服务层存在耦合
   2. 之后，我们将代码修改成：FruitService fruitService = null

      然后在配置文件中配置：
      ```xml
      <bean id="fruit" class="com.controllers.FruitController">
          <property name="fruitService" ref="fruitService"/>
      </bean>
      ```

# 过滤器Filter

1. Filter也属于Servlet规范
2. Filter开发步骤：新建类实现Filter接口，然后实现其中的三个方法：init，doFilter，destory

   配置Filter，可以用注解@WebFilter，也可以使用xml文件\<filter>\<filter-mapping>
3. Filter在配置时，和Servlet一样，也可以配置通配符，例如@WebFilter("*.do")，表示拦截所有以.do结尾的请求
4. 过滤器链
   1. 执行的顺序依次是：A B C demo01 C2 B2 A2
   2. 如果采取的是注解的方式进行配置，那么过滤器链的拦截顺序是按照全类名的先后顺序排序的
   3. 如果采取的是xml的方式进行配置，那么按照配置的先后顺序进行排序

# 事务管理

1. 涉及到的组件

   -- OpenSessionInViewFilter

   -- ThreadLocal

   -- TransctionManager

   -- BasicDAO
2. ThreadLocal

   -- get(), set(obj)

   -- ThreadLocal称之为本地线程，我们可以通过set方法在当前线程上存储数据，通过get方法在当前线程上获取数据

# 监听器

1. ServletContextListener					监听ServletContext对象的创建和销毁的过程
2. HttpSessionListener						监听HttpSession对象的创建和销毁的过程
3. ServletRequestListener					监听ServletRequest对象的创建和销毁的过程
4. ServletContextAttributeListener		监听ServletContext的保存作用域的改动（add，remove，replace）
5. HttpServletAttributeListener			监听HttpSession的保存作用域的改动
6. ServletRequestAttributeListener		监听ServletRequest保存作用域的改动
7. HttpSessionBindingListener			监听某个对象在Session域中的创建和移除
8. HttpSessionActivationListener		监听某个对象在Session中的序列化与反序列化

# ServletContextListener的应用--ContextLoaderListener
