package com.servlets;

import com.bean.Fruit;
import com.myssm.myspringmvc.ViewBaseServlet;
import com.myssm.util.StringUtil;
import com.service.FruitService;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;


@WebServlet("/fruit.do")
public class FruitServlet extends ViewBaseServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("utf-8");
        String operate = req.getParameter("operate");

        if (StringUtil.isEmpty(operate)) {
            operate = "index";
        }


        switch (operate) {
            case "index":
                index(req, resp);
                break;
            case "add":
                add(req, resp);
                break;
            case "delete":
                delete(req, resp);
                break;
            case "edit":
                edit(req, resp);
                break;
            case "update":
                update(req, resp);
                break;
            default:
                throw new RuntimeException("operate值非法");
        }
    }



    private void update(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        //1.设置编码
        FruitService fruitService = new FruitService();

        //2.获取参数
        Integer fid = Integer.parseInt(req.getParameter("fid"));
        String fname = req.getParameter("fname");
        Integer price = Integer.parseInt(req.getParameter("price"));
        Integer fcount = Integer.parseInt(req.getParameter("fcount"));
        String remark = req.getParameter("remark");

        //3.执行更新
        fruitService.updateFruitById(new Fruit(fid, fname, price, fcount, remark));

        //4.资源跳转
        resp.sendRedirect("fruit.do");
    }
    private void edit(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        FruitService fruitService = new FruitService();
        String fidStr = req.getParameter("fid");
        if (!StringUtil.isEmpty(fidStr)) {
            int fid = Integer.parseInt(fidStr);
            Fruit fruitById = fruitService.getFruitById(fid);
            req.setAttribute("fruit", fruitById);
            super.processTemplate("edit", req, resp);
        }
    }
    private void delete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        FruitService fruitService = new FruitService();
        String fidStr = req.getParameter("fid");
        if (!StringUtil.isEmpty(fidStr)) {
            int fid = Integer.parseInt(fidStr);
            fruitService.deleteFruitById(fid);

            resp.sendRedirect("fruit.do");
        }
    }
    private void add(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        FruitService fruitService = new FruitService();

        String fname = req.getParameter("fname");
        Integer price = Integer.parseInt(req.getParameter("price"));
        Integer fcount = Integer.parseInt(req.getParameter("fcount"));
        String remark = req.getParameter("remark");
        fruitService.addFruit(new Fruit(null, fname, price, fcount, remark));

        resp.sendRedirect("fruit.do");
    }
    private void index(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        FruitService fruitService = new FruitService();

        HttpSession session = req.getSession();
        int pageNo = 1;

        String oper = req.getParameter("oper");
        //如果oper==null，说明通过表单的查询按钮点击进来的
        //如果oper!=null，说明不是通过表单的查询按钮点击进来的

        String keyword;
        if (!StringUtil.isEmpty(oper) && "search".equals(oper)) {
            //说明是点击查询按钮发送过来的请求
            //此时pageNo应该还原为1，keyword应该从请求参数中获取
            keyword = req.getParameter("keyword");
            if (StringUtil.isEmpty(keyword)) {
                keyword="";
            }
            session.setAttribute("keyword", keyword);
        } else {
            //说明此处不是点击表单发送过来的请求（比如点击下一页或者直接在地址栏输入网址）
            //keyword应该从session作用域获取
            String pageNoStr = req.getParameter("pageNo");
            if (!StringUtil.isEmpty(pageNoStr)) {
                pageNo = Integer.parseInt(pageNoStr);
            }
            Object keywordObj = session.getAttribute("keyword");
            if (keywordObj != null) {
                keyword = (String) keywordObj;
            } else {
                keyword = "";
            }
        }


        //重新更新当前页面的值
        session.setAttribute("pageNo", pageNo);

        List<Fruit> fruitList = fruitService.getFruitList(keyword, pageNo);
        int fruitCount = fruitService.getFruitCount(keyword);
        session.setAttribute("pageCount", (fruitCount+4)/5);
        //保存到session作用域

        session.setAttribute("fruitList", fruitList);

        //此处的视图名称是index
        //那么thymeleaf会将这个逻辑视图名称对应到物理视图名称上去
        //逻辑视图名称： index
        //物理视图名称： view-prefix + 逻辑视图名称 + view-suffix
        //所以真实的视图名称是： /index.html
        super.processTemplate("index", req, resp);
    }
}
