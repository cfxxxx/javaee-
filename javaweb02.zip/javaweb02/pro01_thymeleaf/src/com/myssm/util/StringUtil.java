package com.myssm.util;

public class StringUtil {
    public static boolean isEmpty(String str) {
        return str == null || "".equals(str);
    }
}
