package com.dao;

import com.bean.Fruit;

import java.util.List;

public class FruitDAO extends BasicDAO<Fruit>{
}
