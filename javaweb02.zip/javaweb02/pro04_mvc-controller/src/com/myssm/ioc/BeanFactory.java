package com.myssm.ioc;

public interface BeanFactory {
    //通过id获取类
    Object getBean(String id);
}
