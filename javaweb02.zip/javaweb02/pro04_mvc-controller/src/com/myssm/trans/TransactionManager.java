package com.myssm.trans;

import com.mysql.jdbc.Connection;
import com.utils.JDBCUtilsByDruid;

import java.sql.SQLException;

public class TransactionManager {
    private static ThreadLocal<Connection> threadLocal = new ThreadLocal<>();


    //开启事务
    public static void beginTransaction() throws SQLException {
        if (threadLocal.get() == null) {
            threadLocal.set((Connection) JDBCUtilsByDruid.getConnection());
        }
        threadLocal.get().setAutoCommit(false);
    }

    //提交事务
    public static void commit() throws SQLException {
        Connection connection = threadLocal.get();
        connection.commit();
        connection.close();
        threadLocal.set(null);
    }

    //回滚事务
    public static void rollback() throws SQLException {
        threadLocal.get().rollback();
    }
}
