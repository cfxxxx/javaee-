package com.myssm.myspringmvc;

import com.myssm.ioc.BeanFactory;
import com.myssm.ioc.ClassPathXmlApplicationContext;
import com.myssm.util.StringUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

@SuppressWarnings("all")
@WebServlet("*.do")
public class DispatcherServlet extends ViewBaseServlet {

    private BeanFactory beanFactory;


    //构造器
    public DispatcherServlet() {
    }

    @Override
    public void init() throws ServletException {
        super.init();
        //之前是在此处主动创建IOC容器的
        //beanFactory = new ClassPathXmlApplicationContext();
        //现在优化为从application作用域获取
        Object beanFactoryObject = getServletContext().getAttribute("beanFactory");
        if (beanFactoryObject != null) {
            beanFactory = (BeanFactory) beanFactoryObject;
        } else {
            throw new RuntimeException("IOC容器获取失败");
        }
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置编码
        //req.setCharacterEncoding("utf-8");

        //假设url是： http://localhost:8080/pro02/hello.do
        //那么servletPath是：/hello.do
        //第一步：/hello.do -> hello
        //第二步：hello -> HelloController
        String servletPath = req.getServletPath();

        String substring = servletPath.substring(1);
        int i = substring.lastIndexOf(".do");
        servletPath = substring.substring(0, i);

        Object beanControllerObject = beanFactory.getBean(servletPath);

        String operate = req.getParameter("operate");

        if (StringUtil.isEmpty(operate)) {
            operate = "index";
        }

        try {
            Method[] methods = beanControllerObject.getClass().getDeclaredMethods();
            for (Method method : methods) {
                if (operate.equals(method.getName())) {
                    //1.统一获取请求参数

                    //获取当前方法的参数数组
                    Parameter[] parameters = method.getParameters();
                    //parameterValues用来承载参数的值
                    Object[] parameterValues = new Object[parameters.length];
                    for (int j = 0; j < parameters.length; j++) {
                        Parameter parameter = parameters[j];
                        String name = parameter.getName();
                        //如果参数名是request,response,session,那么就不是通过请求中获取参数的方式了
                        if (name.equals("req")) {
                            parameterValues[j] = req;
                        } else if (name.equals("resp")) {
                            parameterValues[j] = resp;
                        } else if (name.equals("session")) {
                            parameterValues[j] = req.getSession();
                        } else {
                            String parameterValue = req.getParameter(name);
                            Object parameterObject = parameterValue;

                            String typeName = parameter.getType().getName();
                            if (parameterObject != null) {
                                if (typeName.equals("java.lang.Integer")) {
                                    parameterObject = Integer.parseInt(parameterValue);
                                }
                            }
                            parameterValues[j] = parameterObject;
                        }
                    }


                    //2.controller组件中的方法调用
                    //反射爆破
                    method.setAccessible(true);
                    Object methodReturnObject = method.invoke(beanControllerObject, parameterValues);
                    String methodReturnStr = (String) methodReturnObject;

                    //3.视图处理
                    if (methodReturnStr.startsWith("redirect:")) {//比如redirect:fruit.do
                        String redirectStr = methodReturnStr.substring("redirect:".length());
                        resp.sendRedirect(redirectStr);
                    } else { //比如edit
                        super.processTemplate(methodReturnStr, req, resp);
                    }
                }
            }
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }
}


//常见错误：IllegalArgumentException: argument type mismatch