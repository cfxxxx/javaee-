package com.service;

import com.bean.Fruit;
import com.dao.FruitDAO;

import java.util.List;

@SuppressWarnings("all")
public class FruitService {
    FruitDAO fruitDAO = null;

    //获取指定页码上的库存列表信息，每页显示5条
    public List<Fruit> getFruitList(String keyword, Integer pageNo) {
        return fruitDAO.queryMulti("select * from fruit where fname like ? or remark like ? limit ?,?", com.bean.Fruit.class, "%" + keyword + "%", "%" + keyword + "%", (pageNo-1)*5, pageNo*5);
    }

    //根据fid获取特定的水果库存信息
    public Fruit getFruitById(Integer fid) {
        return fruitDAO.querySingle("select * from fruit where fid=?", Fruit.class, fid);
    }

    //修改库存信息
    public void updateFruitById(Fruit fruit) {
        fruitDAO.update("update fruit set fname=?,price=?,fcount=?,remark=? where fid=?", fruit.getFname(), fruit.getPrice(), fruit.getFcount(), fruit.getRemark(), fruit.getFid());
    }

    //根据fid删除特定水果库存信息
    public void deleteFruitById(int fid) {
        fruitDAO.update("delete from fruit where fid=?", fid);
    }

    //添加库存信息
    public void addFruit(Fruit fruit){
        fruitDAO.update("insert into fruit values(null,?,?,?,?)", fruit.getFname(), fruit.getPrice(), fruit.getFcount(), fruit.getRemark());
    }

    //查询总记录条数
    public int getFruitCount(String keyword) {
        return ((Long) fruitDAO.queryScalar("select count(*) from fruit where fname like ? or remark like ?", "%" + keyword + "%", "%" + keyword + "%")).intValue();
    }

}
