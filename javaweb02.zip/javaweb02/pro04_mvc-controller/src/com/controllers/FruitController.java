package com.controllers;

import com.bean.Fruit;

import com.myssm.util.StringUtil;
import com.service.FruitService;


import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpSession;
import java.io.IOException;

import java.util.List;

@SuppressWarnings("all")
public class FruitController {

    private FruitService fruitService = null;

    //之前的FruitServlet是一个Servlet组件，那么其中的init方法一定会被调用
    //之前的FruitServlet方法内部会出现一句话：super.init()，现在不会自动执行这句话



    private String update(Integer fid, String fname, Integer price, Integer fcount, String remark) {

        //2.获取参数
        //Integer fid = Integer.parseInt(req.getParameter("fid"));
        //String fname = req.getParameter("fname");
        //Integer price = Integer.parseInt(req.getParameter("price"));
        //Integer fcount = Integer.parseInt(req.getParameter("fcount"));
        //String remark = req.getParameter("remark");

        //3.执行更新
        fruitService.updateFruitById(new Fruit(fid, fname, price, fcount, remark));

        //4.资源跳转
        //resp.sendRedirect("fruit.do");
        return "redirect:fruit.do";
    }
    private String edit(Integer fid, HttpServletRequest req) {

        if (fid != null) {
            Fruit fruitById = fruitService.getFruitById(fid);
            req.setAttribute("fruit", fruitById);

            //super.processTemplate("edit", req, resp);
            return "edit";
        }
        return "error";
    }
    private String delete(Integer fid) throws IOException {
        if (fid != null) {
            fruitService.deleteFruitById(fid);

            //resp.sendRedirect("fruit.do");
            return "redirect:fruit.do";
        }
        return "error";
    }
    private String add(String fname, Integer price, Integer fcount, String remark) throws IOException {

        fruitService.addFruit(new Fruit(null, fname, price, fcount, remark));

        //.sendRedirect("fruit.do");
        return "redirect:fruit.do";
    }
    private String index(String oper, String keyword, Integer pageNo, HttpServletRequest req) {

        HttpSession session = req.getSession();

        if (pageNo == null) {
            pageNo = 1;
        }
        if (!StringUtil.isEmpty(oper) && "search".equals(oper)) {
            pageNo = 1;
            if (keyword == null) {
                keyword = "";
            }
            session.setAttribute("keyword", keyword);
        } else {
            Object keywordObj = session.getAttribute("keyword");
            if (keywordObj != null) {
                keyword = (String) keywordObj;
            } else {
                keyword = "";
            }
        }
        session.setAttribute("pageNo", pageNo);
        List<Fruit> fruitList = fruitService.getFruitList(keyword, pageNo);
        session.setAttribute("fruitList", fruitList);
        int fruitCount = fruitService.getFruitCount(keyword);
        session.setAttribute("pageCount", (fruitCount+4)/5);
        return "index";
    }
}
